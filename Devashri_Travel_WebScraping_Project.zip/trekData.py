# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 00:09:54 2022

@author: devas
"""

from bs4 import BeautifulSoup
import requests
from csv import writer

url='https://www.tourmyindia.com/treks/'
page=requests.get(url)
print(page)

soup=BeautifulSoup(page.content,'html.parser')

li=soup.find('div',class_='packages-wi')
        
with open('C:\\Users\\devas\\OneDrive\\Desktop\\Study Material\\Spyder\\webScrapingProject\\dataTreks.csv','a',encoding='utf8',newline='') as f:
            
    twriter=writer(f)
    header=['Name of trek','Duration of trek','Location','Elevation of summit (mts)','Total Distance of Trek (kms)']
    twriter.writerow(header)
    for list1 in li.find_all('div',attrs={'class':['tranding-details']}):
                
        elevation=[]
        distance=[]
        title=list1.find('a').text
        days=list1.find('p').text
        location=list1.find('span').text   
                
        for i in list1.find_all('div',class_='trakking-detail-in'):
                                
            find_all_eg=i.get_text().split()
            # print(find_all_eg)
            elevation.append(find_all_eg[0])
            distance.append(find_all_eg[1]) 
                   
        info=[title,days,location,elevation,distance]        
        twriter.writerow(info)